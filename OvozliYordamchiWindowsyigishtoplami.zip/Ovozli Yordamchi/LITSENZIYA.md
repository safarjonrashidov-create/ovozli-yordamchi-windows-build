# Manba va litsenziya eslatmasi

Asosiy manba: **MARK XXXIX-OR**, FatihMakes: https://github.com/FatihMakes/Mark-XXXIX-OR

Asl loyiha README’sida Creative Commons Attribution-NonCommercial 4.0 International (CC BY-NC 4.0) litsenziyasi ko‘rsatilgan: https://creativecommons.org/licenses/by-nc/4.0/

Ushbu to‘plam asl loyihadan moslashtirilgan. O‘zgarishlar: o‘zbekcha Windows build yo‘riqnomasi, Windows foydalanuvchi papkasidagi DPAPI himoyasi, NVDA/klaviatura boshqaruvlari va build skripti. Bu muallif loyiha yoki hosila buildni ma’qullaydi degani emas. Faqat litsenziyaning notijorat shartlariga rioya qilib foydalaning.

Build skripti Python 3.13.17 Windows x64 o‘rnatuvchisini rasmiy Python manbasidan yuklaydi. FFmpeg va ffprobe Windows binarlari build vaqtida alohida yuklanadi. Gyan.dev sahifasi ishlatilgan FFmpeg buildini GPLv3 deb belgilaydi: https://www.gyan.dev/ffmpeg/builds/ . FFmpeg manba kodi va litsenziya haqida: https://ffmpeg.org/download.html . Boshqa uchinchi tomon paketlarining litsenziyalari ularning mualliflariga tegishli.
