# Tekshirilgan manbalar

- MARK XXXIX-OR asl loyihasi va FatihMakes mualliflik havolasi: https://github.com/FatihMakes/Mark-XXXIX-OR — asl loyiha CC BY-NC 4.0 litsenziyasini ko‘rsatadi.
- Python 3.13.17 Windows x64 rasmiy o‘rnatuvchisi: https://www.python.org/downloads/release/python-31317/ — yig‘ish skripti SHA-256 `5da012101ba2e17113a9a1cd901e9ce1441086f2b7ecb5de06ec94163899a190` qiymatini tekshiradi.
- Python 3.13.18 rasmiy sahifasi: https://www.python.org/downloads/release/python-31318/ — bu faqat xavfsizlik tuzatishlari bo‘lgan manba kodi relizi, Windows o‘rnatuvchisi berilmagan; 3.13.17 esa 3.13 qatori uchun so‘nggi rasmiy Windows o‘rnatuvchisiga ega reliz sifatida tanlandi.
- Gemini API rasmiy model katalogi: https://ai.google.dev/gemini-api/docs/models — 2.5 modellaridan foydalanish avvaldan faol foydalangan foydalanuvchilar bilan cheklanishi mumkin; yangi loyihalar uchun yangi modellar tavsiya etiladi.
- Gemini 3.8 Live modeli: https://ai.google.dev/gemini-api/docs/models/gemini-3.8-live — barqaror model identifikatori `gemini-3.8-live`; matn, tasvir va audio qabul qiladi, matn va audio javob beradi, Live API hamda function calling’ni qo‘llaydi.
- Gemini Live API Python SDK boshlang‘ich qo‘llanmasi: https://ai.google.dev/gemini-api/docs/live-api/get-started-sdk — `genai.Client(api_key=...)`, `client.aio.live.connect(model="gemini-3.8-live", config=...)`, audio kirish/chiqish va vosita javoblari namunasi.
- Gemini Live function calling qo‘llanmasi: https://ai.google.dev/gemini-api/docs/live-tools — function calling qo‘llab-quvvatlanadi; mijoz vosita natijasini `session.send_tool_response` bilan qaytarishi kerak.
- PyAutoGUI PyPI: https://pypi.org/project/PyAutoGUI/ — Windows’da ishlaydi; 0.9.54 relizi source archive sifatida beriladi, shuning uchun qat’iy “faqat wheel” tekshiruvi o‘tkazmaydi, odatiy pip esa manba arxividan o‘rnatadi.
- Python Windows o‘rnatuvchisining foydalanuvchi profiliga o‘rnatish va `/quiet`, `InstallAllUsers`, `TargetDir`, `Include_pip` parametrlari: https://docs.python.org/3/using/windows.html
- Playwright Python’da Chromium o‘rnatish va brauzer yo‘llari: https://playwright.dev/python/docs/browsers
- PyInstaller rasmiy qo‘llanmasi — bir papkali rejim, `--add-data`, `--collect-all` va `--collect-submodules`: https://pyinstaller.org/en/stable/usage.html
- FFmpeg Windows essentials arxivi, `ffmpeg.exe`/`ffprobe.exe` va SHA-256: https://www.gyan.dev/ffmpeg/builds/ (arxiv: https://www.gyan.dev/ffmpeg/builds/packages/ffmpeg-8.1.2-essentials_build.zip ; SHA-256: `db580001caa24ac104c8cb856cd113a87b0a443f7bdf47d8c12b1d740584a2ec`). Gyan sahifasi buildni GPLv3 deb belgilaydi; FFmpeg manbasi: https://ffmpeg.org/download.html
- CC BY-NC 4.0 shartlari: https://creativecommons.org/licenses/by-nc/4.0/

- Gemini Developer API tariflari va bepul/haq to‘lanadigan rejalar: https://aistudio.google.com/docs/pricing — Gemini 3.8 Live uchun alohida tarif jadvali shu sahifadan ochiladi; foydalanish narxi va modelga kirish shartlari hisob rejasi hamda Google’ning amaldagi jadvaliga bog‘liq.

- Gemini Live audio/voice sozlamasi: https://ai.google.dev/gemini-api/docs/live-guide — `response_modalities=["AUDIO"]` hamda `speech_config.voice_config.prebuilt_voice_config.voice_name` shaklini ko‘rsatadi.
- Gemini 3.8 Live tariflari: https://aistudio.google.com/docs/pricing — rasmiy jadvalda bepul rejada audio kirish/chiqish bepul deb ko‘rsatilgan; pullik rejada audio kirish $0.005/min, audio chiqish $0.018/min; bepul reja ma’lumoti Google mahsulotlarini yaxshilashda ishlatilishi mumkin, pullik rejada esa yo‘q. Limitlar va tariflar o‘zgarishi mumkin.

- Gemini 3.8 Live tool chaqiruvlari: https://ai.google.dev/gemini-api/docs/models/gemini-3.8-live — bu modelda `NON_BLOCKING` odatiy holat; eski ketma-ket ishlash tartibini saqlash uchun deklaratsiyada `behavior: "BLOCKING"` belgilanadi. Ilova barcha amallarni shunday sozlaydi.

- Gemini 3.8 Flash rasmiy modeli: https://ai.google.dev/gemini-api/docs/models/gemini-3.8-flash — barqaror endpoint `gemini-3.8-flash`; matn, rasm, video, audio va PDF qabul qiladi, matn qaytaradi, function calling’ni qo‘llaydi.
- Gemini 3.8 Flash tariflari: https://aistudio.google.com/docs/pricing — rasmiy jadvalda bepul reja uchun tokenlar bepul; pullik rejada 2026-yil 31-dekabrgacha kirish $0.75 va chiqish $3.75/1 mln token, 2027-yil 1-yanvardan $1.50 va $7.50/1 mln token deb ko‘rsatilgan. Bepul reja mazmuni Google mahsulotlarini yaxshilashda ishlatilishi mumkin.
