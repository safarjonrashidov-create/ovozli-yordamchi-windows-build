# Ovozli Yordamchi — Windows build to‘plami

Bu to‘plam **MARK XXXIX-OR** manbasiga tayangan holda Windows 10/11 64-bit uchun klaviatura va NVDA bilan boshqariladigan ilova yig‘adi. Hozirgi muhit Windows `.exe`-ni bevosita yig‘a olmaydi; shu sababli `Yigish.bat` faylini Windows kompyuteringizda bir marta ishga tushirish kerak. Skript Python, kutubxonalar, Chromium va audio/video vositalarini yuklab, ilovani tayyorlaydi.

## Ilovada nimalar bor

Gemini 3.8 Live ovozli yordamchi va Gemini 3.8 Flash matn/rasm tahlili, veb-qidiruv, brauzer boshqaruvi, fayllar bilan ishlash, xotira, eslatmalar va kompyuter amallari mavjud. Ayrim qo‘shimcha AI funksiyalari OpenRouter kalitini talab qiladi; u majburiy emas. Terminal, Telegram va brauzer uchun alohida tez ochish tugmalari ham bor.

## Windows’da bir marta yig‘ish

1. ZIP faylni Windows kompyuteringizga yuklab, papkaga chiqaring.
2. NVDA yoqilgan holda chiqarilgan papkadan `Yigish.bat` faylini topib Enter bosing. Administrator ruxsati kerak emas; yig‘ish uchun Windows’dagi `curl.exe` va `certutil.exe` ishlatiladi.
3. Yig‘ish internet tezligiga qarab ancha vaqt olishi mumkin. Bir necha gigabaytgacha vaqtinchalik disk joyi talab qilinishi mumkin. Python foydalanuvchi profilingizga o‘rnatiladi; Windows `PATH`, PowerShell ijro siyosati va himoya sozlamalari o‘zgartirilmaydi.
4. Tayyor ilova `dist\Ovozli Yordamchi\Ovozli Yordamchi.exe` ichida bo‘ladi. Yig‘ish tugasa ish stolida `Ovozli Yordamchi` yorlig‘i ham yaratiladi. Uni ishga tushirish uchun yorliqdan foydalaning; `dist\Ovozli Yordamchi` papkasini o‘chirmang yoki ko‘chirmang.

Yig‘ish Python 3.13.17 Windows x64 o‘rnatuvchisini rasmiy `python.org` saytidan HTTPS orqali olib, SHA-256 bilan tekshiradi. Python va kutubxonalar yig‘ish muhitida alohida turadi; natijadagi EXE ularni qayta o‘rnatishni talab qilmaydi. Chromium va FFmpeg ham ilova papkasiga qo‘shiladi. Build PowerShell ishlatmaydi va Windows ijro siyosatini o‘zgartirmaydi. EXE raqamli imzosiz bo‘lgani uchun Windows ogohlantirishi mumkin. Ogohlantirish bo‘lsa, uni chetlab o‘tmang: yig‘ishni to‘xtating va himoya sozlamalarini o‘zgartirmang.

## Birinchi ishga tushirish va maxfiylik

Birinchi marta ochilganda Gemini API kalitini [Google AI Studio API kalitlari sahifasidan](https://aistudio.google.com/api-keys) oling va ilovaning sozlash oynasiga kiriting. OpenRouter kaliti ayrim qo‘shimcha matnli va tasvirli funksiyalar uchun ixtiyoriy. Kalitlarni chatga yoki yig‘ish papkasiga yozmang: Windows’da ilova ularni shu foydalanuvchi hisobi uchun DPAPI bilan shifrlab, `%LOCALAPPDATA%\Ovozli Yordamchi` papkasida saqlaydi.

Vazifaga qarab ilova mikrofon, ekran/kamera, tanlangan fayllar yoki suhbat xotirasidan foydalanishi va kerakli ma’lumotni Gemini yoki OpenRouter xizmatiga yuborishi mumkin. Mikrofonni F4 bilan o‘chirib qo‘yish mumkin. Eslatma vaqti kelganda Windows hisobingizga kirgan bo‘lsangiz, Task Scheduler Windows tizim xabarini ko‘rsatadi. Xabar yuborish, faylni o‘chirish/ko‘chirish, kod ishga tushirish yoki tizim sozlamalarini o‘zgartirish kabi sezilarli amallarda ilova tasdiq so‘rashi kerak.

## Gemini API tarifi

Google’ning hozirgi tarif jadvalida Gemini 3.8 Live audio kirish-chiqishi bepul rejada bepul, lekin limitlar va modelga kirish shartlari qo‘llanadi. Pullik rejadagi ko‘rsatilgan narxlar: kirayotgan audio uchun **$0.005/minut**, chiqayotgan audio uchun **$0.018/minut**.

Matn va rasm tahlilida ishlatiladigan Gemini 3.8 Flash bepul rejada bepul deb ko‘rsatilgan. Pullik rejada token narxi 2026-yil 31-dekabrgacha kirish uchun **$0.75**, chiqish uchun **$3.75 / 1 mln token**; 2027-yil 1-yanvardan mos ravishda **$1.50** va **$7.50**. Bepul rejadagi so‘rovlar Google mahsulotlarini yaxshilashda ishlatilishi mumkin; pullik rejada bunday foydalanish ko‘rsatilmagan. Google Search grounding qo‘shimcha limit yoki to‘lovga ega bo‘lishi mumkin. Tariflar va modelga kirish shartlari o‘zgaradi — [Google’ning rasmiy tarif sahifasini](https://aistudio.google.com/docs/pricing) tekshiring.

## NVDA va klaviatura

- `F2` buyruq maydoniga, `F3` faoliyat jurnaliga o‘tadi.
- `F4` mikrofonni yoqadi yoki o‘chiradi; `F5` Gemini kaliti sozlamalarini ochadi; `F11` to‘liq ekran rejimini almashtiradi.
- `F5` orqali kalitni o‘zgartirsangiz, ilovani `Alt+F4` bilan yoping va ish stolidagi yorliqdan qayta oching.
- `Tab` va `Shift+Tab` boshqaruvlar orasida yuradi; matnli buyruqni `Enter` bilan yuboring.
- Fayl biriktirish uchun drag-and-drop shart emas; `Fayl tanlash` tugmasidan foydalaning.
- `Tez ochish` qatorida Terminal, Telegram va Brauzer tugmalari bor. Ovozli buyruqda ham “Terminalni och”, “Telegramni och” yoki “Brauzerni och” deyishingiz mumkin.
- Holat va javoblar faoliyat jurnalida ko‘rinadi; jurnalga F3 bilan o‘ting.

## Asl loyiha va litsenziya

Asl loyiha: [FatihMakes/Mark-XXXIX-OR](https://github.com/FatihMakes/Mark-XXXIX-OR), muallifi FatihMakes. Asl loyiha README’sida **Creative Commons Attribution-NonCommercial 4.0 International (CC BY-NC 4.0)** litsenziyasi ko‘rsatilgan. Ushbu paket mualliflik va litsenziya havolasini saqlaydi; o‘zgarishlar Windows build, foydalanuvchi sozlamalarini himoyalash va klaviatura/ekran o‘quvchi bilan kirish imkoniyatlarini yaxshilashdan iborat. Faqat litsenziya shartlariga muvofiq notijorat foydalaning.

[Litsenziya shartlari](https://creativecommons.org/licenses/by-nc/4.0/)
