@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"

if not defined LOCALAPPDATA goto NO_LOCALAPPDATA
where curl.exe >nul 2>&1
if errorlevel 1 goto NO_CURL
where certutil.exe >nul 2>&1
if errorlevel 1 goto NO_CERTUTIL

set "BUILD_ROOT=%LOCALAPPDATA%\Ovozli Yordamchi Yigish"
set "PYTHON_HOME=%BUILD_ROOT%\Python 3.13.17"
set "PYTHON_EXE=%PYTHON_HOME%\python.exe"
set "PYTHON_INSTALLER=%BUILD_ROOT%\python-3.13.17-amd64.exe"
set "EXPECTED_HASH=5da012101ba2e17113a9a1cd901e9ce1441086f2b7ecb5de06ec94163899a190"

if exist "%PYTHON_EXE%" goto PYTHON_READY
if not exist "%BUILD_ROOT%" mkdir "%BUILD_ROOT%"
if errorlevel 1 goto BUILD_ROOT_FAILED

echo Rasmiy Python 3.13.17 o'rnatuvchisi HTTPS orqali yuklanmoqda.
curl.exe --fail --location --silent --show-error --retry 3 --output "%PYTHON_INSTALLER%" "https://www.python.org/ftp/python/3.13.17/python-3.13.17-amd64.exe"
if errorlevel 1 goto PYTHON_DOWNLOAD_FAILED

set "PYTHON_HASH="
for /f "skip=1 tokens=1" %%H in ('certutil -hashfile "%PYTHON_INSTALLER%" SHA256') do if not defined PYTHON_HASH set "PYTHON_HASH=%%H"
if /I not "%PYTHON_HASH%"=="%EXPECTED_HASH%" goto PYTHON_HASH_FAILED

echo Python foydalanuvchi profilingizga o'rnatilmoqda. Administrator huquqi va PATH o'zgarishi talab qilinmaydi.
start "" /wait "%PYTHON_INSTALLER%" /quiet InstallAllUsers=0 "TargetDir=%PYTHON_HOME%" Include_launcher=0 Include_doc=0 Include_test=0 Include_pip=1 Include_tcltk=0 PrependPath=0 Shortcuts=0
if not exist "%PYTHON_EXE%" goto PYTHON_INSTALL_FAILED

:PYTHON_READY
set "PYTHONUTF8=1"
echo Ovozli Yordamchi yig'ish jarayoni boshlandi. Windows xavfsizlik sozlamalari o'zgartirilmaydi.
"%PYTHON_EXE%" "%~dp0Yigish.py"
set "BUILD_RESULT=%ERRORLEVEL%"
echo.
if "%BUILD_RESULT%"=="0" echo Yig'ish muvaffaqiyatli yakunlandi.
if not "%BUILD_RESULT%"=="0" echo Yig'ish yakunlanmadi. Jurnalni tekshiring.
pause
exit /b %BUILD_RESULT%

:NO_LOCALAPPDATA
echo XATOLIK: Windows foydalanuvchi profil papkasi topilmadi.
goto FAILED
:NO_CURL
echo XATOLIK: Windows curl.exe topilmadi. Uni yuklab olish yoki xavfsizlik sozlamalarini o'zgartirishga urinmang.
goto FAILED
:NO_CERTUTIL
echo XATOLIK: Windows certutil.exe topilmadi.
goto FAILED
:BUILD_ROOT_FAILED
echo XATOLIK: Foydalanuvchi profilida vaqtinchalik yig'ish papkasi yaratilmadi.
goto FAILED
:PYTHON_DOWNLOAD_FAILED
echo XATOLIK: Python o'rnatuvchisini yuklab bo'lmadi. Internet aloqasini tekshiring.
goto FAILED
:PYTHON_HASH_FAILED
echo XATOLIK: Python o'rnatuvchisining SHA-256 tekshiruvi mos kelmadi. Fayl ishga tushirilmadi.
goto FAILED
:PYTHON_INSTALL_FAILED
echo XATOLIK: Python foydalanuvchi profiliga o'rnatilmadi.
goto FAILED
:FAILED
echo Windows himoyasini o'chirmang va ogohlantirishlarni chetlab o'tmang.
pause
exit /b 1
