from __future__ import annotations

import hashlib
import os
import shutil
import subprocess
import sys
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LOCALAPPDATA = Path(os.environ.get("LOCALAPPDATA", str(Path.home())))
BUILD_ROOT = LOCALAPPDATA / "Ovozli Yordamchi Yigish"
VENV = BUILD_ROOT / "Python 3.13.17 venv"
VENV_PYTHON = VENV / "Scripts" / "python.exe"
BROWSER_PATH = BUILD_ROOT / "playwright-browsers"
LOG_PATH = ROOT / "Ovozli Yordamchi yigish jurnali.txt"
FFMPEG_URL = "https://www.gyan.dev/ffmpeg/builds/packages/ffmpeg-8.1.2-essentials_build.zip"
FFMPEG_SHA256 = "db580001caa24ac104c8cb856cd113a87b0a443f7bdf47d8c12b1d740584a2ec"
LOG = None


def say(message: str = "") -> None:
    print(message, flush=True)
    if LOG is not None:
        LOG.write(message + "\n")
        LOG.flush()


def run(args: list[str | Path], *, cwd: Path = ROOT) -> None:
    command = [str(arg) for arg in args]
    say("\n> " + " ".join(command))
    process = subprocess.Popen(
        command,
        cwd=str(cwd),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        bufsize=1,
    )
    assert process.stdout is not None
    for line in process.stdout:
        print(line, end="", flush=True)
        if LOG is not None:
            LOG.write(line)
            LOG.flush()
    code = process.wait()
    if code:
        raise RuntimeError(f"Buyruq xato kodi bilan tugadi: {code}")


def download(url: str, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    request = urllib.request.Request(
        url,
        headers={"User-Agent": "Ovozli-Yordamchi-Windows-Builder/1.0"},
    )
    say(f"Yuklanmoqda: {url}")
    with urllib.request.urlopen(request, timeout=120) as response, target.open("wb") as out:
        total = int(response.headers.get("Content-Length", "0") or 0)
        received = 0
        last_percent = -10
        while True:
            chunk = response.read(1024 * 1024)
            if not chunk:
                break
            out.write(chunk)
            received += len(chunk)
            if total:
                percent = received * 100 // total
                if percent >= last_percent + 10:
                    say(f"Yuklandi: {percent}%")
                    last_percent = percent
    say("Yuklab olish yakunlandi.")


def ensure_venv() -> None:
    if sys.version_info[:3] != (3, 13, 17):
        raise RuntimeError("Yig'ish uchun rasmiy Python 3.13.17 kerak.")
    BUILD_ROOT.mkdir(parents=True, exist_ok=True)
    if VENV.exists():
        shutil.rmtree(VENV)
    say("Alohida, faqat yig'ish uchun ishlatiladigan Python muhiti yaratilmoqda.")
    run([sys.executable, "-m", "venv", str(VENV)])
    run([VENV_PYTHON, "-m", "pip", "install", "--upgrade", "pip"])
    say("Loyiha kutubxonalari o'rnatilmoqda. Bu internet tezligiga qarab vaqt oladi.")
    run([VENV_PYTHON, "-m", "pip", "install", "-r", ROOT / "requirements-windows.txt"])


def ensure_chromium() -> None:
    BROWSER_PATH.mkdir(parents=True, exist_ok=True)
    os.environ["PLAYWRIGHT_BROWSERS_PATH"] = str(BROWSER_PATH)
    os.environ["PLAYWRIGHT_SKIP_BROWSER_GC"] = "1"
    say("Brauzer boshqaruvi uchun Chromium yuklanmoqda.")
    run([VENV_PYTHON, "-m", "playwright", "install", "chromium"])


def ensure_ffmpeg() -> Path:
    target_dir = ROOT / "build-assets" / "ffmpeg"
    ffmpeg_exe = target_dir / "ffmpeg.exe"
    ffprobe_exe = target_dir / "ffprobe.exe"
    target_dir.mkdir(parents=True, exist_ok=True)
    if ffmpeg_exe.is_file() and ffprobe_exe.is_file():
        return target_dir

    archive = BUILD_ROOT / "ffmpeg-8.1.2-essentials_build.zip"
    download(FFMPEG_URL, archive)
    digest = hashlib.sha256()
    with archive.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    if digest.hexdigest().lower() != FFMPEG_SHA256:
        archive.unlink(missing_ok=True)
        raise RuntimeError("FFmpeg arxivining SHA-256 tekshiruvi mos kelmadi; arxiv ochilmadi.")

    extract_dir = BUILD_ROOT / "ffmpeg-extracted"
    if extract_dir.exists():
        shutil.rmtree(extract_dir)
    extract_dir.mkdir(parents=True)
    with zipfile.ZipFile(archive) as package:
        base = extract_dir.resolve()
        for item in package.infolist():
            destination = (extract_dir / item.filename).resolve()
            if destination != base and base not in destination.parents:
                raise RuntimeError("FFmpeg arxivida ruxsat etilmagan fayl yo'li topildi.")
        package.extractall(extract_dir)

    ffmpeg_source = next(extract_dir.rglob("ffmpeg.exe"), None)
    ffprobe_source = next(extract_dir.rglob("ffprobe.exe"), None)
    if ffmpeg_source is None or ffprobe_source is None:
        raise RuntimeError("Tekshirilgan FFmpeg arxivida ffmpeg.exe yoki ffprobe.exe topilmadi.")
    shutil.copy2(ffmpeg_source, ffmpeg_exe)
    shutil.copy2(ffprobe_source, ffprobe_exe)
    notice = (
        "FFmpeg and ffprobe are separate third-party utilities.\n"
        "This Windows build is marked GPLv3 by Gyan.dev.\n"
        "Build source and license information: https://www.gyan.dev/ffmpeg/builds/\n"
        "FFmpeg source: https://ffmpeg.org/download.html\n"
    )
    (target_dir / "FFmpeg license notice.txt").write_text(notice, encoding="utf-8")
    return target_dir


def build_app(ffmpeg_dir: Path) -> Path:
    os.environ["PYTHONPATH"] = str(ROOT)
    os.environ["PYTHONUTF8"] = "1"
    os.environ["PLAYWRIGHT_BROWSERS_PATH"] = str(BROWSER_PATH)
    os.environ["PLAYWRIGHT_SKIP_BROWSER_GC"] = "1"

    dist_root = ROOT / "dist"
    work = ROOT / "build"
    for path in (dist_root, work):
        if path.exists():
            shutil.rmtree(path)

    args: list[str | Path] = [
        VENV_PYTHON, "-m", "PyInstaller", "--noconfirm", "--clean", "--onedir", "--windowed",
        "--name", "Ovozli Yordamchi", "--distpath", dist_root, "--workpath", work,
        "--add-data", f"{ROOT / 'core' / 'prompt.txt'};core",
        "--add-data", f"{ffmpeg_dir};ffmpeg",
        "--add-data", f"{BROWSER_PATH};playwright-browsers",
        "--collect-all", "PyQt6", "--collect-all", "google.genai", "--collect-all", "google.generativeai",
        "--collect-all", "playwright", "--collect-all", "sounddevice", "--collect-all", "numpy",
        "--collect-all", "cv2", "--collect-all", "pandas", "--collect-all", "pdfplumber",
        "--collect-all", "openpyxl", "--collect-all", "comtypes", "--collect-all", "pycaw",
        "--collect-all", "pywinauto", "--collect-all", "imageio_ffmpeg", "--collect-all", "ddgs",
        "--collect-submodules", "actions", "--collect-submodules", "agent", "--collect-submodules", "memory",
        "--collect-submodules", "config", "--hidden-import", "win32timezone", "--hidden-import", "pythoncom",
        "--hidden-import", "pywintypes", "--hidden-import", "websockets", ROOT / "main.py",
    ]
    say("Ilova yig'ilmoqda. Yaratilgan EXE papkasini to'liq saqlang.")
    run(args)
    output_dir = dist_root / "Ovozli Yordamchi"
    output_exe = output_dir / "Ovozli Yordamchi.exe"
    if not output_exe.is_file():
        raise RuntimeError("PyInstaller tugadi, lekin kutilgan EXE fayli topilmadi.")
    return output_exe


def create_shortcut(exe: Path) -> None:
    try:
        from win32com.client import Dispatch
        shell = Dispatch("WScript.Shell")
        desktop = Path(shell.SpecialFolders("Desktop"))
        shortcut = shell.CreateShortcut(str(desktop / "Ovozli Yordamchi.lnk"))
        shortcut.TargetPath = str(exe)
        shortcut.WorkingDirectory = str(exe.parent)
        shortcut.Description = "Ovozli va matnli shaxsiy yordamchi"
        shortcut.IconLocation = f"{exe},0"
        shortcut.Save()
        say(f"Ish stoliga yorliq yaratildi: {desktop / 'Ovozli Yordamchi.lnk'}")
    except Exception as exc:
        say(f"Ish stoliga yorliq yaratilmadi; EXE shu yerda: {exe}")
        say(f"Yorliq xabari: {exc}")


def main() -> int:
    global LOG
    with LOG_PATH.open("w", encoding="utf-8") as log_file:
        LOG = log_file
        try:
            if os.name != "nt" or not sys.platform.startswith("win"):
                raise RuntimeError("Bu yig'ish dasturi Windows kompyuterida ishga tushiriladi.")
            if not (ROOT / "requirements-windows.txt").is_file():
                raise RuntimeError("requirements-windows.txt loyiha papkasida topilmadi.")
            say("Ovozli Yordamchi Windows yig'ish jarayoni boshlandi.")
            say("Windows xavfsizlik siyosati o'zgartirilmaydi; administrator huquqi so'ralmaydi.")
            ensure_venv()
            ensure_chromium()
            ffmpeg_dir = ensure_ffmpeg()
            exe = build_app(ffmpeg_dir)
            create_shortcut(exe)
            say("Yig'ish muvaffaqiyatli yakunlandi.")
            say(f"Ilova EXE fayli: {exe}")
            say(f"Ilova papkasi: {exe.parent}")
            say("Ilovani ishga tushirishda dist\\Ovozli Yordamchi papkasini o'chirmang yoki ko'chirmang.")
            return 0
        except Exception as exc:
            say(f"XATOLIK: {exc}")
            say(f"Batafsil jurnal: {LOG_PATH}")
            return 1
        finally:
            LOG = None


if __name__ == "__main__":
    raise SystemExit(main())
