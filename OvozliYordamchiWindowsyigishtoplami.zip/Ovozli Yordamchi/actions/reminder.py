"""Schedule local Windows reminders through Task Scheduler and msg.exe."""
from __future__ import annotations

import os
import subprocess
import tempfile
import xml.etree.ElementTree as ET
from datetime import datetime


_TASK_NS = "http://schemas.microsoft.com/windows/2004/02/mit/task"
ET.register_namespace("", _TASK_NS)


def _tag(name: str) -> str:
    return f"{{{_TASK_NS}}}{name}"


def _build_task_xml(
    task_name: str,
    target_dt: datetime,
    message: str,
    msg_exe: str,
    user_id: str = "",
    user_name: str = "",
) -> str:
    """Create a least-privilege task whose only action is Windows msg.exe."""
    arguments = subprocess.list2cmdline([user_name or "*", "/TIME:30", message])

    root = ET.Element(_tag("Task"), {"version": "1.2"})
    registration = ET.SubElement(root, _tag("RegistrationInfo"))
    ET.SubElement(registration, _tag("Description")).text = "Ovozli Yordamchi eslatmasi"

    triggers = ET.SubElement(root, _tag("Triggers"))
    trigger = ET.SubElement(triggers, _tag("TimeTrigger"))
    ET.SubElement(trigger, _tag("StartBoundary")).text = target_dt.strftime("%Y-%m-%dT%H:%M:%S")
    ET.SubElement(trigger, _tag("Enabled")).text = "true"

    principals = ET.SubElement(root, _tag("Principals"))
    principal = ET.SubElement(principals, _tag("Principal"), {"id": "Author"})
    if user_id:
        ET.SubElement(principal, _tag("UserId")).text = user_id
    ET.SubElement(principal, _tag("LogonType")).text = "InteractiveToken"
    ET.SubElement(principal, _tag("RunLevel")).text = "LeastPrivilege"

    settings = ET.SubElement(root, _tag("Settings"))
    ET.SubElement(settings, _tag("MultipleInstancesPolicy")).text = "IgnoreNew"
    ET.SubElement(settings, _tag("DisallowStartIfOnBatteries")).text = "false"
    ET.SubElement(settings, _tag("StopIfGoingOnBatteries")).text = "false"
    ET.SubElement(settings, _tag("StartWhenAvailable")).text = "true"
    ET.SubElement(settings, _tag("WakeToRun")).text = "true"
    ET.SubElement(settings, _tag("ExecutionTimeLimit")).text = "PT1M"
    ET.SubElement(settings, _tag("Enabled")).text = "true"

    actions = ET.SubElement(root, _tag("Actions"), {"Context": "Author"})
    action = ET.SubElement(actions, _tag("Exec"))
    ET.SubElement(action, _tag("Command")).text = msg_exe
    ET.SubElement(action, _tag("Arguments")).text = arguments

    return ET.tostring(root, encoding="unicode", xml_declaration=False)


def reminder(
    parameters: dict,
    response: str | None = None,
    player=None,
    session_memory=None,
) -> str:
    """Schedule a local Windows reminder; the Live API voices the result."""
    if os.name != "nt":
        return "Eslatma funksiyasi hozircha faqat Windows uchun."

    date_str = str(parameters.get("date") or "").strip()
    time_str = str(parameters.get("time") or "").strip()
    message = str(parameters.get("message") or "Eslatma vaqti keldi.")

    if not date_str or not time_str:
        return "Eslatma uchun sana va vaqtni kiriting."

    try:
        target_dt = datetime.strptime(f"{date_str} {time_str}", "%Y-%m-%d %H:%M")
    except ValueError:
        return "Sana yoki vaqt formati noto‘g‘ri. Sana YYYY-MM-DD, vaqt HH:MM shaklida bo‘lsin."

    if target_dt <= datetime.now():
        return "Tanlangan vaqt o‘tib ketgan. Kelajakdagi sana va vaqtni tanlang."

    safe_message = " ".join(message.replace("\x00", "").split())[:200]
    if not safe_message:
        safe_message = "Eslatma vaqti keldi."

    task_name = f"OvozliYordamchiEslatma{target_dt.strftime('%Y%m%d%H%M%S')}"
    windows_dir = os.environ.get("WINDIR", r"C:\Windows")
    msg_exe = os.path.join(windows_dir, "System32", "msg.exe")
    if not os.path.isfile(msg_exe):
        return "Windows tizim xabari dasturi topilmadi; eslatmani rejalashtirib bo‘lmadi."

    user_id = ""
    try:
        identity = subprocess.run(
            ["whoami"], capture_output=True, text=True, timeout=5, check=False
        )
        if identity.returncode == 0:
            user_id = identity.stdout.strip()
    except Exception:
        pass
    user_name = os.environ.get("USERNAME", "").strip()
    if not user_name and user_id:
        user_name = user_id.rsplit("\\", 1)[-1]
    if not user_name:
        return "Windows foydalanuvchisi aniqlanmadi; eslatmani rejalashtirib bo‘lmadi."

    temp_dir = os.environ.get("TEMP") or tempfile.gettempdir()
    xml_path = os.path.join(temp_dir, f"{task_name}.xml")
    xml_content = _build_task_xml(
        task_name, target_dt, safe_message, msg_exe, user_id, user_name
    )

    try:
        root = ET.fromstring(xml_content)
        ET.ElementTree(root).write(xml_path, encoding="utf-16", xml_declaration=True)
        result = subprocess.run(
            ["schtasks.exe", "/Create", "/TN", task_name, "/XML", xml_path, "/F"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=30,
            check=False,
        )
    except Exception as exc:
        return f"Eslatmani rejalashtirishda xatolik yuz berdi: {str(exc)[:100]}"
    finally:
        try:
            os.remove(xml_path)
        except OSError:
            pass

    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "").strip()
        suffix = f" Tafsilot: {detail[:120]}" if detail else ""
        return "Eslatmani Windows rejalashtira olmadi." + suffix

    if player:
        try:
            player.write_log(f"[eslatma] {date_str} {time_str} ga belgilandi")
        except Exception:
            pass

    return f"Eslatma {date_str} kuni soat {time_str} ga belgilandi."
