"""Ovozli Yordamchi agent modullari."""
