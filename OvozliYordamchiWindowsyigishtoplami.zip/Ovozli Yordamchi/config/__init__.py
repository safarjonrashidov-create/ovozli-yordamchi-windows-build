"""Per-user configuration and Windows DPAPI credential storage."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any

APP_NAME = "Ovozli Yordamchi"


def app_data_dir() -> Path:
    base = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA")
    if not base:
        base = str(Path.home() / ".local" / "share")
    path = Path(base) / APP_NAME
    path.mkdir(parents=True, exist_ok=True)
    return path


def resource_path(relative: str | Path) -> Path:
    """Resolve read-only resources both from source and PyInstaller builds."""
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        root = Path(sys._MEIPASS)
    else:
        root = Path(__file__).resolve().parent.parent
    return root / relative


CONFIG_DIR = app_data_dir() / "config"
SETTINGS_FILE = CONFIG_DIR / "settings.json"
CREDENTIALS_FILE = CONFIG_DIR / "api-credentials.dat"
_CONFIG_PATH = CREDENTIALS_FILE


def _protect(data: bytes) -> bytes:
    if os.name != "nt":
        return b"OA-LOCAL-1\0" + data
    import ctypes
    from ctypes import wintypes

    class DataBlob(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_ubyte))]

    crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    crypt32.CryptProtectData.argtypes = [
        ctypes.POINTER(DataBlob), wintypes.LPCWSTR, ctypes.POINTER(DataBlob),
        ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(DataBlob)
    ]
    crypt32.CryptProtectData.restype = wintypes.BOOL
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p

    source_buffer = ctypes.create_string_buffer(data)
    source = DataBlob(len(data), ctypes.cast(source_buffer, ctypes.POINTER(ctypes.c_ubyte)))
    output = DataBlob()
    if not crypt32.CryptProtectData(ctypes.byref(source), "Ovozli Yordamchi API credentials", None, None, None, 1, ctypes.byref(output)):
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        return ctypes.string_at(output.pbData, output.cbData)
    finally:
        kernel32.LocalFree(output.pbData)


def _unprotect(data: bytes) -> bytes:
    if os.name != "nt":
        prefix = b"OA-LOCAL-1\0"
        return data[len(prefix):] if data.startswith(prefix) else data
    import ctypes
    from ctypes import wintypes

    class DataBlob(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_ubyte))]

    crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    crypt32.CryptUnprotectData.argtypes = [
        ctypes.POINTER(DataBlob), ctypes.POINTER(wintypes.LPWSTR), ctypes.POINTER(DataBlob),
        ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(DataBlob)
    ]
    crypt32.CryptUnprotectData.restype = wintypes.BOOL
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p

    source_buffer = ctypes.create_string_buffer(data)
    source = DataBlob(len(data), ctypes.cast(source_buffer, ctypes.POINTER(ctypes.c_ubyte)))
    output = DataBlob()
    if not crypt32.CryptUnprotectData(ctypes.byref(source), None, None, None, None, 1, ctypes.byref(output)):
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        return ctypes.string_at(output.pbData, output.cbData)
    finally:
        kernel32.LocalFree(output.pbData)


def _read_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


def load_api_keys() -> dict[str, Any]:
    settings = _read_json(SETTINGS_FILE)
    credentials: dict[str, Any] = {}
    if CREDENTIALS_FILE.exists():
        try:
            value = json.loads(_unprotect(CREDENTIALS_FILE.read_bytes()).decode("utf-8"))
            if isinstance(value, dict):
                credentials = value
        except Exception:
            credentials = {}
    return {**settings, **credentials}


def save_config(values: dict[str, Any]) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    current = load_api_keys()
    current.update(values)
    secret_names = {"gemini_api_key", "openrouter_api_key"}
    secrets = {name: str(current.get(name, "")).strip() for name in secret_names}
    settings = {name: value for name, value in current.items() if name not in secret_names}
    SETTINGS_FILE.write_text(json.dumps(settings, indent=2, ensure_ascii=False), encoding="utf-8")
    encrypted = _protect(json.dumps(secrets, ensure_ascii=False).encode("utf-8"))
    CREDENTIALS_FILE.write_bytes(encrypted)
    if os.name != "nt":
        os.chmod(SETTINGS_FILE, 0o600)
        os.chmod(CREDENTIALS_FILE, 0o600)


def save_api_keys(gemini_api_key: str, openrouter_api_key: str, os_system: str) -> None:
    openrouter_api_key = openrouter_api_key.strip() or (get_openrouter_key() or "")
    save_config({
        "gemini_api_key": gemini_api_key.strip(),
        "openrouter_api_key": openrouter_api_key.strip(),
        "os_system": os_system,
    })


def get_config() -> dict[str, Any]:
    return load_api_keys()


def get_os() -> str:
    return str(load_api_keys().get("os_system", "windows")).lower()


def get_gemini_key() -> str | None:
    value = load_api_keys().get("gemini_api_key")
    return str(value) if value else None


def get_openrouter_key() -> str | None:
    value = load_api_keys().get("openrouter_api_key")
    return str(value) if value else None


def is_configured() -> bool:
    values = load_api_keys()
    return bool(values.get("gemini_api_key") and values.get("os_system"))


def is_windows() -> bool:
    return get_os() == "windows"


def is_mac() -> bool:
    return get_os() == "mac"


def is_linux() -> bool:
    return get_os() == "linux"
