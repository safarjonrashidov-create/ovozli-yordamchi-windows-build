"""Compatibility wrappers around the central per-user configuration store."""
from config import (
    CONFIG_DIR,
    CREDENTIALS_FILE,
    get_gemini_key,
    get_openrouter_key,
    is_configured,
    load_api_keys,
    save_api_keys as _save_api_keys,
    save_config,
)

CONFIG_FILE = CREDENTIALS_FILE


def ensure_config_dir() -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def config_exists() -> bool:
    return is_configured()


def save_api_keys(gemini_api_key: str, openrouter_api_key: str = "", os_system: str = "windows") -> None:
    current = load_api_keys()
    _save_api_keys(
        gemini_api_key,
        openrouter_api_key or str(current.get("openrouter_api_key", "")),
        os_system or str(current.get("os_system", "windows")),
    )


def get_gemini_key_compat() -> str | None:
    return get_gemini_key()


def load_api_keys_compat() -> dict:
    return load_api_keys()
